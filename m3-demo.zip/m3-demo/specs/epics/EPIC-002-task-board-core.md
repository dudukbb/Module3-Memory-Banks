# Epic: Core Task Board Management

## Description

This epic delivers the central feature of Taskboard: a Kanban-style board where users can create, view, edit, and organize tasks across workflow columns. It provides the primary interface for daily task management, including drag-and-drop status updates and detailed task views.

This is the core value proposition of the product—enabling teams to visualize and manage their work efficiently.

## Primary Persona

**Target User:** Sarah - The Developer

**Key Needs:**
- Quick way to see her assigned tasks at a glance
- Easy drag-and-drop to update task status without friction
- View of what teammates are working on
- Fast, responsive interface that doesn't slow her down

## Success Criteria

- [ ] Users can create a new task in under 30 seconds
- [ ] Drag-and-drop status updates complete in < 500ms (perceived instant)
- [ ] Task board displays all tasks correctly in their respective columns
- [ ] Page load time < 2 seconds for board with up to 100 tasks
- [ ] All CRUD operations work correctly without data loss
- [ ] **PRD Metric**: "Time to Update" task status < 5 seconds
- [ ] **PRD Metric**: Contributes to "Task Throughput" improvement

## Scope/Complexity

**Estimate:** L (Large)

**Rationale:** Core feature with multiple UI components (board, columns, cards, modals), drag-and-drop implementation, full CRUD operations, and task assignment. Requires both frontend complexity (React components, state management) and backend APIs. Critical path for product value.

## Dependencies

### Required (Must exist before work begins)
- [ ] EPIC-001-user-authentication completed (need authenticated user context)
- [ ] Database schema for tasks and users deployed
- [ ] Frontend project structure and design system established

### Related (May impact or be impacted by this work)
- EPIC-003-real-time-sync (will add live updates to this board)
- EPIC-004-notifications (triggered by task changes made here)

### Assumptions
- Three fixed columns for MVP: "To Do", "In Progress", "Done"
- Single shared board per team (no multi-project support in MVP)
- Task assignment limited to registered team members
- Priority field is informational only (no automated sorting)

## User Stories

### Planned
- [ ] US-010 - As a user, I want to see all tasks on a Kanban board so that I can understand project status at a glance
- [ ] US-011 - As a user, I want to create a new task with title and description so that I can add work items
- [ ] US-012 - As a user, I want to move tasks between columns via drag-and-drop so that I can update status efficiently
- [ ] US-013 - As a user, I want to view task details in a modal so that I can see full information
- [ ] US-014 - As a user, I want to edit task details so that I can update information as work progresses
- [ ] US-015 - As a user, I want to delete tasks so that I can remove completed or cancelled items
- [ ] US-016 - As a user, I want to assign tasks to team members so that ownership is clear
- [ ] US-017 - As a user, I want to set due dates on tasks so that deadlines are visible
- [ ] US-018 - As a user, I want to see task counts per column so that I can gauge workload distribution
- [ ] US-019 - As a user, I want to see assignee avatars on task cards so that I can quickly identify ownership

### Completed
_(None yet)_

---

## Additional Notes

**Technical Considerations:**
- Use react-beautiful-dnd or @dnd-kit for drag-and-drop
- Implement optimistic UI updates for perceived performance
- Task position field for ordering within columns
- Lazy load task descriptions (show on expand only)
- Consider virtualization if task count exceeds 100

**UI Components Required:**
- TaskBoard (main container with columns)
- TaskColumn (To Do, In Progress, Done)
- TaskCard (compact card in column)
- TaskDetailModal (full task view/edit)
- CreateTaskModal (new task form)
- AssigneeSelector (dropdown with team members)
- DueDatePicker (date input component)

**Out of Scope:**
- Custom columns (fixed 3-column workflow for MVP)
- Task priorities (visual indicator only, no sorting)
- Subtasks or checklists
- Task comments (separate epic or post-MVP)
- Search and filter functionality (post-MVP)
- Keyboard shortcuts (post-MVP)
- File attachments

**Open Questions:**
- [ ] Should tasks have a "Blocked" status or just use "In Progress"?
- [ ] What happens to task position when dragged to a new column? (Suggest: add to bottom)
- [ ] Should deleted tasks be soft-deleted or hard-deleted? (Suggest: hard delete for MVP)

**PRD References:**
- Functional Requirements: FR-2.1 through FR-2.5, FR-3.1 through FR-3.7
- User Stories: P0 items for task creation, viewing, updating, assignment
- UX Section: Task Board Layout, Task Card Design, Task Detail Modal
- API Endpoints: GET/POST/PATCH/DELETE /api/tasks, GET /api/users
