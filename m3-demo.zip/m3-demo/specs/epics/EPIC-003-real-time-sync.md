# Epic: Real-Time Collaboration & Sync

## Description

This epic transforms Taskboard from a standard web app into a live, collaborative workspace. It enables instant synchronization of task changes across all connected users via WebSocket, eliminating the need for manual page refreshes and ensuring everyone sees the current state of the board.

Additionally, it provides team presence awareness by showing which users are currently online and viewing the board.

## Primary Persona

**Target User:** Mike - The Team Lead

**Key Needs:**
- Overview of all tasks and their statuses without refreshing
- Quick identification of team activity and presence
- Visibility into project progress for status reporting
- Reduced need for "what's the status?" interruptions

## Success Criteria

- [ ] Task changes appear on other users' screens within 500ms
- [ ] Online presence indicators update within 2 seconds of user activity
- [ ] WebSocket reconnects automatically within 5 seconds of connection loss
- [ ] System handles 10 concurrent WebSocket connections without performance degradation
- [ ] No data loss or race conditions when multiple users edit simultaneously
- [ ] **PRD Metric**: Contributes to "Daily Active Users (DAU)" by making the board a live reference
- [ ] **PRD Metric**: Contributes to "50% reduction in Status Meeting Time" by providing real-time visibility

## Scope/Complexity

**Estimate:** M (Medium)

**Rationale:** WebSocket implementation is well-understood pattern but requires careful handling of connection lifecycle, reconnection logic, and event synchronization. Online presence is straightforward once WebSocket is established. Main complexity is ensuring data consistency across clients.

## Dependencies

### Required (Must exist before work begins)
- [ ] EPIC-001-user-authentication completed (need user identity for presence)
- [ ] EPIC-002-task-board-core completed (need tasks to synchronize)
- [ ] WebSocket server infrastructure ready (Socket.io or native WS)

### Related (May impact or be impacted by this work)
- EPIC-002-task-board-core (will receive live update events)
- EPIC-004-notifications (may share event triggers)

### Assumptions
- Socket.io or native WebSocket is the chosen real-time transport
- Server can maintain persistent WebSocket connections for all team members
- Client-side state management can handle incoming updates efficiently
- Network conditions are generally stable (internal company network)

## User Stories

### Planned
- [ ] US-020 - As a user, I want to see task changes from teammates in real-time so that I always have current information
- [ ] US-021 - As a user, I want to see when a new task is created by a teammate without refreshing
- [ ] US-022 - As a user, I want to see when a task is moved to a different column by a teammate
- [ ] US-023 - As a user, I want to see which team members are currently online so that I know who's working
- [ ] US-024 - As a user, I want the connection to automatically reconnect if it drops so that I don't lose sync
- [ ] US-025 - As a user, I want to see a visual indicator when I'm disconnected so that I know updates may be stale
- [ ] US-026 - As a user, I want task updates from my own actions to feel instant (optimistic UI)

### Completed
_(None yet)_

---

## Additional Notes

**Technical Considerations:**
- WebSocket Events to implement:
  - `task:created` - New task added
  - `task:updated` - Task details modified
  - `task:deleted` - Task removed
  - `task:moved` - Task changed column/position
  - `user:online` - User connected
  - `user:offline` - User disconnected
- Implement heartbeat/ping-pong for connection health
- Use exponential backoff for reconnection attempts
- Consider message queuing for offline-then-reconnect scenarios
- Debounce rapid updates to prevent event flooding

**UI Components Required:**
- ConnectionStatusIndicator (shows connected/disconnected state)
- OnlineUsersList (shows team members currently viewing)
- UserPresenceAvatar (green dot indicator on avatars)
- Toast/notification for reconnection events

**Out of Scope:**
- Cursor presence (showing where other users are looking)
- Collaborative editing of task descriptions
- Typing indicators
- Detailed activity feed/history
- Offline mode with sync-on-reconnect
- Push notifications (browser notifications)

**Open Questions:**
- [ ] Should we show a subtle animation when a task updates from another user?
- [ ] How to handle conflicts if two users move the same task simultaneously? (Suggest: last-write-wins)
- [ ] Should disconnected users still see a read-only view? (Suggest: yes, with stale data warning)

**PRD References:**
- Functional Requirements: FR-2.4 (real-time updates), FR-4.3 (online presence)
- Non-Functional Requirements: Real-time latency < 500ms, Auto-reconnect within 5 seconds
- WebSocket Events: task:created, task:updated, task:deleted, task:moved, user:online, user:offline
- Technical Architecture: WebSocket Server component
