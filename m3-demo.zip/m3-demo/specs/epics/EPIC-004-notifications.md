# Epic: Email Notifications & Alerts

## Description

This epic implements an email notification system that keeps team members informed about task changes relevant to them, even when they're not actively viewing the board. It ensures users never miss important updates like new task assignments, status changes, or approaching deadlines.

By proactively pushing information to users, this epic drives engagement and reinforces Taskboard as the source of truth for project status.

## Primary Persona

**Target User:** Sarah - The Developer

**Key Needs:**
- Notifications when tasks assigned to her change so she stays informed
- Timely reminders about approaching deadlines
- Control over notification frequency to avoid email overload
- Clear, actionable email content that links back to the task

## Success Criteria

- [ ] Notification emails are sent within 60 seconds of triggering event
- [ ] Email delivery success rate exceeds 95%
- [ ] Users can configure notification preferences (on/off per type)
- [ ] Due date reminder emails sent 24 hours before deadline
- [ ] Unsubscribe/preferences link included in all notification emails
- [ ] **PRD Metric**: Contributes to "Daily Active Users (DAU)" by re-engaging users via email
- [ ] **PRD Metric**: Supports "Task Throughput" by ensuring assignees are aware of their tasks

## Scope/Complexity

**Estimate:** M (Medium)

**Rationale:** Email sending is straightforward with Nodemailer/SMTP, but requires event triggering logic, template management, preference storage, and handling of edge cases (user unsubscribed, invalid email, etc.). Due date scheduling adds background job complexity.

## Dependencies

### Required (Must exist before work begins)
- [ ] EPIC-001-user-authentication completed (need user emails and preferences)
- [ ] EPIC-002-task-board-core completed (need task events to trigger notifications)
- [ ] SMTP server configured and accessible
- [ ] User notification_preferences field in database

### Related (May impact or be impacted by this work)
- EPIC-003-real-time-sync (may share event triggers, but email is async)

### Assumptions
- Internal SMTP server is available with sufficient sending capacity
- Users have valid, monitored email addresses
- Email deliverability is not a concern (internal corporate email)
- No need for email verification during registration (trusted environment)

## User Stories

### Planned
- [ ] US-030 - As a user, I want to receive an email when a task is assigned to me so that I know I have new work
- [ ] US-031 - As a user, I want to receive an email when my assigned task's status changes so that I stay informed
- [ ] US-032 - As a user, I want to receive an email reminder 24 hours before a task is due so that I don't miss deadlines
- [ ] US-033 - As a user, I want to configure which notifications I receive so that I can control email volume
- [ ] US-034 - As a user, I want notification emails to link directly to the task so that I can take action quickly
- [ ] US-035 - As a user, I want each notification email to clearly state what changed and who made the change

### Completed
_(None yet)_

---

## Additional Notes

**Technical Considerations:**
- Use Nodemailer with company SMTP server
- Email templates (HTML + plain text fallback):
  - Task assigned notification
  - Task status changed notification
  - Due date reminder (24 hours before)
- Notification preferences stored in User.notification_preferences (JSON):
  ```json
  {
    "task_assigned": true,
    "task_status_changed": true,
    "due_date_reminder": true
  }
  ```
- Use a job scheduler (node-cron or similar) for due date reminders
- Include unsubscribe/preferences link in email footer

**Email Template Elements:**
- Clear subject line: "[Taskboard] Task assigned: {task_title}"
- Task title and brief description
- Who made the change (if applicable)
- Direct link to task
- Timestamp of change
- Link to notification preferences

**Out of Scope:**
- In-app notification center
- Browser push notifications
- Slack/Teams integration
- Digest emails (daily/weekly summaries)
- @mention notifications in comments (comments are post-MVP)
- SMS notifications
- Notification history/log viewing

**Open Questions:**
- [ ] Should we batch notifications if multiple changes happen quickly? (Suggest: no, send immediately for MVP)
- [ ] What's the "from" address for notification emails? (Suggest: noreply@company.com)
- [ ] Should task creator receive notifications for their own tasks? (Suggest: no, only assignee)

**PRD References:**
- Functional Requirements: FR-5.1 through FR-5.4
- User Story: "As a user, I want to receive email notifications when tasks assigned to me change"
- Technical Architecture: Email Service (Nodemailer) component
- Infrastructure Needs: SMTP server access
