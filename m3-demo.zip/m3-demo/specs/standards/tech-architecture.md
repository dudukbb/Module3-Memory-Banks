# Technical Architecture Standards

<!-- This document defines the technical architecture standards for mrello. Use this as a reference when making architectural decisions and as context for AI coding tools to ensure consistent implementation. -->

## Project Overview

**Project Name:** mrello  
**Project Type:** Web Application  
**Last Updated:** February 18, 2026

## Technology Stack

### Core Technologies

**Programming Language(s):** TypeScript 5.x

TypeScript is the primary language for both frontend and backend services, ensuring type safety across the entire codebase.

**Runtime/Platform:** Node.js 20.x LTS

Node.js provides the runtime environment for the Express.js backend services and development tooling.

### Frontend

**Framework:** Next.js 14+

Next.js provides server-side rendering, static site generation, and client-side navigation with the App Router architecture.

**UI Library/Components:** Tailwind CSS 3.x

Tailwind CSS is used for utility-first styling. All components should use Tailwind classes for consistent styling.

**State Management:** Redux Toolkit

Redux Toolkit (RTK) manages global application state with the following patterns:
- Use `createSlice` for defining reducers and actions
- Use `RTK Query` for API data fetching and caching
- Keep store slices feature-based (e.g., `boardsSlice`, `cardsSlice`, `authSlice`)

**Build Tools:** Turbopack / Next.js built-in

Leverage Next.js built-in compilation and bundling with Turbopack for development.

### Backend

**Framework:** Express.js 4.x

Express.js powers each microservice with a consistent structure and middleware configuration.

**API Style:** REST

RESTful API design with the following conventions:
- Use HTTP methods appropriately (GET, POST, PUT, PATCH, DELETE)
- Resource-based URL structure (e.g., `/api/v1/boards`, `/api/v1/boards/:id/lists`)
- JSON request/response bodies
- Standard HTTP status codes

**Authentication:** JWT (JSON Web Tokens)

JWT-based authentication with the following implementation:
- Access tokens (short-lived, 15 minutes)
- Refresh tokens (long-lived, 7 days, stored in httpOnly cookies)
- Token validation middleware on protected routes
- bcrypt for password hashing (minimum 12 rounds)

### Database

**Primary Database:** PostgreSQL 16

PostgreSQL serves as the primary relational database for all services. Each microservice should have its own database schema or isolated database.

**ORM/Query Builder:** Prisma 5.x

Prisma ORM for type-safe database access:
- Define schemas in `prisma/schema.prisma`
- Use Prisma Client for all database operations
- Run migrations with `prisma migrate`
- Use Prisma Studio for database exploration during development

**Caching (if applicable):** In-memory caching (Node.js)

For initial implementation, use in-memory caching with node-cache or similar. Consider Redis if caching needs grow.

### Infrastructure & DevOps

**Hosting/Cloud Provider:** Self-hosted

Self-hosted infrastructure with the following stack:
- Docker containers for each microservice
- Docker Compose for local development
- Kubernetes (K8s) or Docker Swarm for production orchestration
- Nginx as reverse proxy and load balancer

**CI/CD:** GitHub Actions

GitHub Actions workflows for:
- Automated testing on pull requests
- Build and push Docker images on merge to main
- Automated deployment to staging/production
- Security scanning (Dependabot, CodeQL)

**Monitoring & Logging:** Simple logging + Prometheus/Grafana

- Winston for structured logging in each service
- Log aggregation to centralized location
- Prometheus for metrics collection
- Grafana dashboards for visualization
- Health check endpoints for each service

**Package Manager:** npm or pnpm

pnpm is recommended for its efficiency with monorepo structures:
- Workspaces for shared code
- Strict dependency resolution
- Fast installation with content-addressable storage

## Architecture Patterns

### Overall Architecture Style

**Pattern:** Microservices

The application is decomposed into independently deployable services, each responsible for a specific domain.

**Rationale:** 
- Independent scaling of services based on load
- Technology flexibility per service (though we standardize on TypeScript)
- Isolated failures—one service down doesn't crash the entire app
- Team autonomy—different teams can own different services
- Easier to understand individual services

**Service Boundaries:**

| Service | Responsibility | Database |
|---------|---------------|----------|
| `auth-service` | User authentication, registration, JWT management | PostgreSQL (users, sessions) |
| `board-service` | Boards, lists, cards, labels management | PostgreSQL (boards, lists, cards) |
| `notification-service` | Email, in-app notifications | PostgreSQL (notifications) |
| `gateway-service` | API Gateway, routing, rate limiting | None (stateless) |

### Frontend Architecture

**Component Structure:** Feature-based organization

Components organized by feature/domain:
- `components/ui/` - Reusable UI primitives (Button, Card, Modal)
- `components/boards/` - Board-related components
- `components/auth/` - Authentication-related components
- `app/` - Next.js App Router pages

**Routing:** File-based routing (Next.js App Router)

```
app/
├── (auth)/
│   ├── login/page.tsx
│   └── register/page.tsx
├── (dashboard)/
│   ├── boards/page.tsx
│   └── boards/[boardId]/page.tsx
├── layout.tsx
└── page.tsx
```

**Data Fetching:** RTK Query + Server Components

- Use RTK Query for client-side data fetching and caching
- Leverage Next.js Server Components for initial data loading
- Implement optimistic updates for better UX

### Backend Architecture (Microservices)

**Layer Organization per Service:**

- **Routes Layer (Controllers):** HTTP request handling, input validation, response formatting
- **Service Layer:** Business logic, orchestration, domain rules
- **Repository Layer:** Database operations via Prisma
- **Models Layer:** Prisma schema definitions, TypeScript interfaces

**Dependency Flow:** Routes → Services → Repositories → Database

```
┌─────────────────┐
│     Routes      │  ← HTTP requests
├─────────────────┤
│    Services     │  ← Business logic
├─────────────────┤
│  Repositories   │  ← Data access
├─────────────────┤
│     Prisma      │  ← ORM
├─────────────────┤
│   PostgreSQL    │  ← Database
└─────────────────┘
```

**Inter-Service Communication:**

- REST APIs for synchronous communication
- Consider message queues (RabbitMQ/Redis Pub/Sub) for async events as the system grows

## Project Structure

### Monorepo Organization

```
mrello/
├── apps/
│   ├── web/                    # Next.js frontend application
│   │   ├── app/                # App Router pages
│   │   ├── components/         # React components
│   │   ├── lib/                # Utilities and helpers
│   │   ├── store/              # Redux store configuration
│   │   └── styles/             # Global styles
│   ├── gateway/                # API Gateway service
│   │   ├── src/
│   │   │   ├── routes/
│   │   │   ├── middleware/
│   │   │   └── index.ts
│   │   └── package.json
│   ├── auth-service/           # Authentication microservice
│   │   ├── src/
│   │   │   ├── routes/
│   │   │   ├── services/
│   │   │   ├── repositories/
│   │   │   └── index.ts
│   │   ├── prisma/
│   │   └── package.json
│   └── board-service/          # Board management microservice
│       ├── src/
│       │   ├── routes/
│       │   ├── services/
│       │   ├── repositories/
│       │   └── index.ts
│       ├── prisma/
│       └── package.json
├── packages/
│   ├── shared/                 # Shared types, utilities
│   │   ├── src/
│   │   │   ├── types/
│   │   │   └── utils/
│   │   └── package.json
│   ├── ui/                     # Shared UI component library
│   │   ├── src/
│   │   └── package.json
│   └── eslint-config/          # Shared ESLint configuration
├── docker/
│   ├── docker-compose.yml      # Local development
│   └── docker-compose.prod.yml # Production
├── .github/
│   └── workflows/              # GitHub Actions CI/CD
├── package.json                # Root package.json (workspaces)
├── pnpm-workspace.yaml         # pnpm workspace config
├── turbo.json                  # Turborepo configuration
└── README.md
```

### File Naming Conventions

**Components/Classes:** PascalCase
```
BoardCard.tsx
UserProfile.tsx
AuthService.ts
```

**Utilities/Helpers:** camelCase
```
formatDate.ts
validateEmail.ts
parseToken.ts
```

**Test Files:** `*.test.ts` or `*.spec.ts`
```
BoardCard.test.tsx
authService.spec.ts
```

**Config Files:** kebab-case or standard names
```
tailwind.config.ts
tsconfig.json
docker-compose.yml
```

## Integration Patterns

### API Communication

**Internal Service Communication:**
- Gateway routes requests to appropriate services
- Services communicate via internal REST APIs
- Use service discovery or static configuration for service URLs
- Implement circuit breakers for resilience

**External APIs:**
- Wrap external services in adapter classes
- Implement retry logic with exponential backoff
- Cache responses where appropriate
- Log all external API calls

**Error Handling:**
```typescript
// Standard error response format
interface ApiError {
  statusCode: number;
  message: string;
  error: string;
  details?: Record<string, unknown>;
}

// HTTP status codes
// 200 - Success
// 201 - Created
// 400 - Bad Request (validation errors)
// 401 - Unauthorized (missing/invalid token)
// 403 - Forbidden (insufficient permissions)
// 404 - Not Found
// 500 - Internal Server Error
```

### State Management

**Global State (Redux):**
- Authentication state (user, tokens)
- UI state (theme, sidebar collapsed)
- Entity state (boards, lists, cards via RTK Query)

**Local State (useState/useReducer):**
- Form inputs
- Modal open/close states
- Component-specific UI state

**Server State (RTK Query):**
```typescript
// Example: boards API slice
export const boardsApi = createApi({
  reducerPath: 'boardsApi',
  baseQuery: fetchBaseQuery({ baseUrl: '/api/v1' }),
  tagTypes: ['Board', 'List', 'Card'],
  endpoints: (builder) => ({
    getBoards: builder.query<Board[], void>({
      query: () => '/boards',
      providesTags: ['Board'],
    }),
    createBoard: builder.mutation<Board, CreateBoardDto>({
      query: (body) => ({ url: '/boards', method: 'POST', body }),
      invalidatesTags: ['Board'],
    }),
  }),
});
```

### Event Handling

**User Events:**
- Handle in React components with event handlers
- Use debounce/throttle for expensive operations
- Optimistic updates for better perceived performance

**System Events:**
- WebSocket connections for real-time updates (board changes)
- Polling as fallback for simpler implementations
- Consider Server-Sent Events (SSE) for one-way notifications

## Infrastructure Standards

### Environment Configuration

**Environment Variables:**

Each service uses `.env` files (never committed to git):
```
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/dbname

# JWT
JWT_SECRET=your-secret-key
JWT_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d

# Service URLs
AUTH_SERVICE_URL=http://localhost:3001
BOARD_SERVICE_URL=http://localhost:3002

# Node
NODE_ENV=development
PORT=3000
```

**Required Environments:**
- [x] Development (local Docker Compose)
- [x] Staging (for QA testing)
- [x] Production (self-hosted servers)

### Deployment Strategy

**Deployment Method:** Docker-based CI/CD

1. Push to `main` branch triggers GitHub Actions
2. Run tests and build Docker images
3. Push images to container registry
4. Deploy to Kubernetes/Docker Swarm
5. Rolling updates with health checks

**Versioning:** Semantic Versioning (semver)

- Format: `MAJOR.MINOR.PATCH` (e.g., `1.2.3`)
- MAJOR: Breaking changes
- MINOR: New features (backward compatible)
- PATCH: Bug fixes

### Performance Standards

**Target Metrics:**
- **Page Load Time:** < 3 seconds (First Contentful Paint)
- **API Response Time:** < 200ms for 95th percentile
- **Bundle Size:** < 300KB initial JS (gzipped)
- **Lighthouse Score:** > 85 for all categories
- **Database Query Time:** < 100ms for 95th percentile

### Security Standards

**Authentication Requirements:**
- [x] All API endpoints require authentication (except `/auth/*`)
- [x] Passwords hashed with bcrypt (minimum 12 rounds)
- [x] JWT tokens validated on every request
- [x] Refresh tokens stored in httpOnly cookies
- [x] Rate limiting on authentication endpoints

**Data Protection:**
- [x] HTTPS required for all communications
- [x] Sensitive data encrypted at rest
- [x] Input validation on all endpoints
- [x] SQL injection prevention (Prisma parameterized queries)
- [x] XSS prevention (React's built-in escaping)
- [x] CORS configured for allowed origins only

## Testing Standards

### Testing Strategy

**Unit Tests:**
- Test all business logic in service layer
- Minimum 80% code coverage
- Use Jest as the test runner
- Mock database calls in unit tests

**Integration Tests:**
- Test API endpoints with Supertest
- Test database operations with test database
- Run on every pull request

**E2E Tests:**
- Test critical user flows (login, create board, add card)
- Use Playwright for browser automation
- Run on staging before production deploy

### Test Organization

**Test File Location:** Alongside source files
```
src/
├── services/
│   ├── boardService.ts
│   └── boardService.test.ts
├── routes/
│   ├── boardRoutes.ts
│   └── boardRoutes.test.ts
```

**Test Naming Convention:**
```typescript
describe('BoardService', () => {
  describe('createBoard', () => {
    it('should create a new board with valid data', async () => {
      // ...
    });

    it('should throw error when name is missing', async () => {
      // ...
    });
  });
});
```

## Documentation Standards

### Code Documentation

**Required Documentation:**
- [x] README.md with setup instructions in each service
- [x] API documentation (OpenAPI/Swagger)
- [x] Component documentation (Storybook for UI components)
- [x] Architecture Decision Records (ADRs) for major decisions
- [x] Environment setup guide
- [x] Deployment runbook

**Inline Comments:**
- Explain "why," not "what"
- Use JSDoc for public functions and APIs
- Document complex algorithms
- Mark TODOs with ticket numbers

```typescript
/**
 * Creates a new board for the authenticated user.
 * @param userId - The ID of the user creating the board
 * @param data - Board creation data
 * @returns The newly created board
 * @throws {ValidationError} If board name is invalid
 */
async createBoard(userId: string, data: CreateBoardDto): Promise<Board> {
  // ...
}
```

## Third-Party Dependencies

### Dependency Guidelines

**Adding Dependencies:**
1. Check bundle size impact (bundlephobia.com)
2. Verify library is actively maintained (last update < 6 months)
3. Review license compatibility
4. Document why the dependency is needed
5. Prefer well-established libraries with strong community

**Allowed Licenses:**
- MIT
- Apache 2.0
- BSD (2-clause, 3-clause)
- ISC

**Prohibited Licenses:**
- GPL (for production code)
- AGPL
- Any copyleft license

**Update Strategy:**
- Enable Dependabot for security updates
- Monthly review of dependency updates
- Quarterly major version updates (with testing)
- Document breaking changes in migration notes

### Key Dependencies

| Category | Package | Version | Purpose |
|----------|---------|---------|---------|
| Frontend | next | 14.x | React framework |
| Frontend | @reduxjs/toolkit | 2.x | State management |
| Frontend | tailwindcss | 3.x | Styling |
| Backend | express | 4.x | HTTP server |
| Backend | prisma | 5.x | ORM |
| Backend | jsonwebtoken | 9.x | JWT handling |
| Backend | bcrypt | 5.x | Password hashing |
| Testing | jest | 29.x | Test runner |
| Testing | playwright | 1.x | E2E testing |

---

## Validation Checklist

Use this checklist when making architectural decisions:

- [x] **Consistency:** Does this align with our existing technology stack?
- [x] **Scalability:** Can this scale with our expected growth?
- [x] **Maintainability:** Will the team be able to maintain this long-term?
- [x] **Performance:** Does this meet our performance requirements?
- [x] **Security:** Have security implications been considered?
- [x] **Cost:** Is the cost (licensing, hosting, development time) acceptable?
- [x] **Team Skills:** Does the team have expertise in this technology?
- [x] **Community Support:** Is there good documentation and community support?
- [x] **Testing:** Can this be easily tested?
- [x] **Documentation:** Is this decision documented for future reference?

## Revision History

| Date | Author | Changes |
|------|--------|---------|
| February 18, 2026 | System | Initial architecture definition |

---

## Assumptions Made

The following assumptions were made during the generation of this document:

1. **Service Boundaries:** Assumed a typical Trello-like domain model with auth, boards, and notifications as primary service boundaries
2. **Database per Service:** Each microservice has its own database/schema for isolation
3. **Local Development:** Docker Compose is used for local multi-service development
4. **Production Orchestration:** Kubernetes or Docker Swarm for production (specific choice left flexible)
5. **Caching:** Started with in-memory caching; Redis can be added as caching needs grow
6. **Real-time:** WebSocket support assumed for board collaboration features
7. **Monorepo:** Used monorepo structure for easier code sharing across services
8. **API Versioning:** REST APIs versioned with `/api/v1/` prefix
