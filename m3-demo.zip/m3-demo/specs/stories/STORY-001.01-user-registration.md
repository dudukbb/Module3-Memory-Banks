# Story ID: STORY-001.01 - User Registration

## User Story

**As a** new team member  
**I want** to register with my email and password  
**So that** I can create an account and access the team's task board

## Acceptance Criteria

- [ ] **Given** I am on the login page, **When** I click "Create Account" or "Register", **Then** I see a registration form with email, password, name, and confirm password fields
- [ ] **Given** I fill in valid details (name, email, password, confirm password), **When** I submit the form, **Then** my account is created and I am automatically logged in and redirected to the task board
- [ ] **Given** I enter an email that already exists, **When** I submit the form, **Then** I see an error "An account with this email already exists"
- [ ] **Given** I enter a password shorter than 8 characters, **When** I submit the form, **Then** I see an error "Password must be at least 8 characters"
- [ ] **Given** my password and confirm password do not match, **When** I submit the form, **Then** I see an error "Passwords do not match"

## Technical Notes

**Implementation Hints:**
- Use bcrypt with cost factor 12+ for password hashing
- Validate email format on both client and server side
- Store user in PostgreSQL with fields: id, email, password_hash, name, created_at
- Return JWT token in HTTP-only cookie upon successful registration
- Implement CSRF token protection on the registration form

**Affected Components:**
- RegistrationForm component (frontend)
- AuthController.register() (backend API)
- UserRepository.create() (data layer)
- User database table

**API Endpoint:**
- POST /api/auth/register
  - Request: { name, email, password }
  - Response: { user: { id, name, email } } + Set-Cookie: jwt

## Estimation

**Story Points:** 3

**Rationale:** Standard registration flow but requires secure password hashing, form validation (client + server), database integration, and JWT cookie setup. Well-understood pattern but multiple components to wire together.

## Related Links

- **Epic:** [EPIC-001-user-authentication](../epics/EPIC-001-user-authentication.md)
- **PRD Reference:** FR-1.1 (System shall allow users to register with email and password)

---

## INVEST Validation

- [x] **Independent** - Can be developed first with no dependencies on other stories
- [x] **Negotiable** - Describes registration outcome, not specific UI implementation
- [x] **Valuable** - Essential for users to access the application
- [x] **Estimable** - Standard auth pattern, team can size it
- [x] **Small** - Completable in 2-3 days
- [x] **Testable** - Clear acceptance criteria with specific error messages
