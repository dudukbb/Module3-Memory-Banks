# Story ID: STORY-001.02 - User Login

## User Story

**As a** registered user  
**I want** to log in with my email and password  
**So that** I can access my team's task board securely

## Acceptance Criteria

- [ ] **Given** I am on the login page, **When** I enter valid email and password and click "Log In", **Then** I am redirected to the task board
- [ ] **Given** I enter an incorrect password, **When** I submit the form, **Then** I see an error "Invalid email or password" (generic to prevent email enumeration)
- [ ] **Given** I enter an email that doesn't exist, **When** I submit the form, **Then** I see the same error "Invalid email or password"
- [ ] **Given** I submit the form with empty fields, **When** I click "Log In", **Then** I see validation errors for required fields
- [ ] **Given** I am already logged in, **When** I navigate to the login page, **Then** I am redirected to the task board automatically

## Technical Notes

**Implementation Hints:**
- Compare password using bcrypt.compare() against stored hash
- Issue JWT token with user ID and set as HTTP-only cookie (24-hour expiration)
- Use generic error message to prevent user enumeration attacks
- Implement CSRF token protection on the login form
- Consider rate limiting: 5 failed attempts triggers 15-minute lockout

**Affected Components:**
- LoginForm component (frontend)
- AuthController.login() (backend API)
- UserRepository.findByEmail() (data layer)
- AuthMiddleware (for redirect if already authenticated)

**API Endpoint:**
- POST /api/auth/login
  - Request: { email, password }
  - Response: { user: { id, name, email } } + Set-Cookie: jwt
  - Error Response: { error: "Invalid email or password" }

## Estimation

**Story Points:** 2

**Rationale:** Simpler than registration - no new user creation, primarily credential verification and token issuance. Standard login flow with well-known patterns.

## Related Links

- **Epic:** [EPIC-001-user-authentication](../epics/EPIC-001-user-authentication.md)
- **PRD Reference:** FR-1.2 (System shall allow users to log in with email and password)
- **Depends On:** STORY-001.01 (need registered users to test login)

---

## INVEST Validation

- [x] **Independent** - Can be developed after registration, minimal dependencies
- [x] **Negotiable** - Describes login outcome, UI details flexible
- [x] **Valuable** - Essential for returning users to access the app
- [x] **Estimable** - Simple auth flow, easy to size
- [x] **Small** - Completable in 1-2 days
- [x] **Testable** - Clear pass/fail criteria for valid and invalid credentials
