# Story ID: STORY-001.03 - Session Persistence

## User Story

**As a** logged-in user  
**I want** my session to persist across browser refreshes and tabs  
**So that** I don't have to log in repeatedly during my workday

## Acceptance Criteria

- [ ] **Given** I am logged in, **When** I refresh the browser page, **Then** I remain logged in and see the task board
- [ ] **Given** I am logged in, **When** I open the app in a new browser tab, **Then** I am automatically logged in on that tab
- [ ] **Given** I am logged in, **When** I close the browser and reopen it within 24 hours, **Then** I am still logged in
- [ ] **Given** my session has expired (after 24 hours), **When** I try to access the task board, **Then** I am redirected to the login page with message "Session expired, please log in again"
- [ ] **Given** I am not logged in, **When** I try to access the task board directly, **Then** I am redirected to the login page

## Technical Notes

**Implementation Hints:**
- JWT stored in HTTP-only cookie automatically sent with requests
- Backend validates JWT on each protected route via AuthMiddleware
- Frontend checks auth status on app initialization (GET /api/auth/me)
- Store minimal data in JWT (user ID only), fetch user details on validation
- Handle 401 responses by redirecting to login page

**Affected Components:**
- App.js / AuthProvider (frontend - auth state management)
- AuthMiddleware (backend - JWT validation on protected routes)
- AuthController.getCurrentUser() (backend - /api/auth/me endpoint)
- ProtectedRoute component (frontend - route guards)

**API Endpoint:**
- GET /api/auth/me
  - Request: Cookie with JWT
  - Response: { user: { id, name, email } }
  - Error Response (401): { error: "Unauthorized" }

## Estimation

**Story Points:** 2

**Rationale:** Primarily middleware and frontend auth state setup. JWT validation is straightforward, main work is wiring up protected routes and handling the auth check on app load.

## Related Links

- **Epic:** [EPIC-001-user-authentication](../epics/EPIC-001-user-authentication.md)
- **PRD Reference:** FR-1.3 (System shall maintain user sessions with secure tokens)
- **Depends On:** STORY-001.02 (need login to establish session)

---

## INVEST Validation

- [x] **Independent** - Session management is separate from login/logout logic
- [x] **Negotiable** - Describes persistence behavior, implementation flexible
- [x] **Valuable** - Reduces friction, improves daily user experience
- [x] **Estimable** - Standard JWT session pattern, well understood
- [x] **Small** - Completable in 1-2 days
- [x] **Testable** - Clear scenarios for refresh, new tab, and expiration
