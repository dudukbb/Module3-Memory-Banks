# Story ID: STORY-001.04 - User Logout

## User Story

**As a** logged-in user  
**I want** to log out of the application  
**So that** I can secure my account when using shared or public devices

## Acceptance Criteria

- [ ] **Given** I am logged in, **When** I click my profile avatar/menu in the header, **Then** I see a "Log Out" option
- [ ] **Given** I click "Log Out", **When** the action completes, **Then** I am redirected to the login page
- [ ] **Given** I have logged out, **When** I try to access the task board URL directly, **Then** I am redirected to the login page
- [ ] **Given** I have logged out, **When** I use the browser back button, **Then** I cannot access protected pages (redirected to login)
- [ ] **Given** I log out in one tab, **When** I have the app open in another tab and try to perform an action, **Then** I am redirected to the login page

## Technical Notes

**Implementation Hints:**
- Clear the JWT cookie by setting an expired cookie on logout
- Optionally maintain a token blacklist/revocation for immediate invalidation (nice-to-have)
- Frontend should clear any cached user state on logout
- Redirect to login page after clearing auth state
- Handle logout while performing async operations gracefully

**Affected Components:**
- UserProfileMenu component (frontend - contains logout button)
- AuthController.logout() (backend API)
- AuthProvider / auth state (frontend - clear user context)

**API Endpoint:**
- POST /api/auth/logout
  - Request: Cookie with JWT
  - Response: { success: true } + Set-Cookie: jwt=; Expires=past date
  - (Clears the auth cookie)

## Estimation

**Story Points:** 1

**Rationale:** Simple feature - clear cookie and redirect. The simplest story in this Epic, mostly frontend UI work with a simple backend endpoint.

## Related Links

- **Epic:** [EPIC-001-user-authentication](../epics/EPIC-001-user-authentication.md)
- **PRD Reference:** FR-1.4 (System shall allow users to log out and invalidate their session)
- **Depends On:** STORY-001.02 (need to be logged in to log out)

---

## INVEST Validation

- [x] **Independent** - Logout is a standalone feature
- [x] **Negotiable** - Menu placement and styling are flexible
- [x] **Valuable** - Security feature for shared device scenarios
- [x] **Estimable** - Very simple, clear scope
- [x] **Small** - Completable in 0.5-1 day
- [x] **Testable** - Easy to verify cookie cleared and redirect works
