# Story ID: STORY-001.05 - Password Reset via Email

## User Story

**As a** user who forgot my password  
**I want** to reset my password via email  
**So that** I can regain access to my account without contacting support

## Acceptance Criteria

- [ ] **Given** I am on the login page, **When** I click "Forgot Password?", **Then** I see a form to enter my email address
- [ ] **Given** I enter a valid registered email, **When** I submit the forgot password form, **Then** I see a message "If this email exists, you will receive a password reset link" and an email is sent
- [ ] **Given** I enter an email that doesn't exist, **When** I submit the form, **Then** I see the same message (prevents email enumeration)
- [ ] **Given** I received the reset email, **When** I click the reset link within 1 hour, **Then** I see a form to enter a new password
- [ ] **Given** I enter a new valid password (8+ characters), **When** I submit, **Then** my password is updated and I am redirected to login with success message "Password reset successful. Please log in."
- [ ] **Given** my reset link has expired (after 1 hour), **When** I click it, **Then** I see an error "This reset link has expired. Please request a new one."

## Technical Notes

**Implementation Hints:**
- Generate secure random token (crypto.randomBytes) with 1-hour expiration
- Store token hash in database (not plain token) with expiration timestamp
- Email contains link: `https://app/reset-password?token=xxxxx`
- Use same generic message for found/not-found emails to prevent enumeration
- Delete/invalidate token after successful password reset (single use)
- Use Nodemailer with company SMTP server

**Affected Components:**
- ForgotPasswordForm component (frontend)
- ResetPasswordForm component (frontend)
- AuthController.forgotPassword() (backend)
- AuthController.resetPassword() (backend)
- EmailService.sendPasswordReset() (backend)
- PasswordResetToken database table/model

**API Endpoints:**
- POST /api/auth/forgot-password
  - Request: { email }
  - Response: { message: "If this email exists..." }
- POST /api/auth/reset-password
  - Request: { token, newPassword }
  - Response: { success: true } or { error: "Invalid or expired token" }

**Email Template:**
- Subject: "[Taskboard] Password Reset Request"
- Body: Reset link + expiration notice + "If you didn't request this, ignore this email"

## Estimation

**Story Points:** 5

**Rationale:** Most complex story in this Epic. Involves token generation, email sending, two new forms, token validation, and security considerations. Multiple moving parts but well-understood pattern.

## Related Links

- **Epic:** [EPIC-001-user-authentication](../epics/EPIC-001-user-authentication.md)
- **PRD Reference:** FR-1.5 (System shall provide password reset via email)
- **Depends On:** STORY-001.01 (need registered users), SMTP server configured

---

## INVEST Validation

- [x] **Independent** - Self-contained feature, only needs user registration
- [x] **Negotiable** - Email template and UI flexible, security patterns fixed
- [x] **Valuable** - Critical for user self-service, reduces support burden
- [x] **Estimable** - Well-known pattern, team can estimate confidently
- [x] **Small** - At upper limit (3 days) but still fits in sprint
- [x] **Testable** - Clear scenarios for valid/invalid/expired tokens
