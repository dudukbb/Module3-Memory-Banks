# API & Data Standards

<!-- This document defines the API and data standards for [Project Name]. Use this as a reference when designing APIs and data models, and as context for AI coding tools to ensure consistent API design and data handling across the project. -->

## Overview

**Project Name:** [Project Name]  
**API Style:** [REST / GraphQL / gRPC / tRPC / etc.]  
**Last Updated:** [Date]

## API Design Principles

### General Principles

**Base URL:** [API base URL pattern]

<!-- Examples: https://api.example.com/v1, /api/v1, https://example.com/api -->

**Versioning Strategy:** [How APIs are versioned]

<!-- Examples: URL versioning (/v1/), Header versioning, Query parameter (?version=1) -->

**API Style Guidelines:**
- [Principle 1 - e.g., "Use nouns for resource endpoints, not verbs"]
- [Principle 2 - e.g., "Keep URLs consistent and predictable"]
- [Principle 3 - e.g., "Use HTTP methods correctly (GET, POST, PUT, DELETE)"]
- [Principle 4 - e.g., "Return appropriate HTTP status codes"]

### RESTful Conventions (if applicable)

**Resource Naming:**

- **Plural nouns for collections:** [Pattern]
  <!-- Example: /users, /tasks, /orders -->
  
- **Singular for single resource:** [Pattern]
  <!-- Example: /users/{id}, /tasks/{taskId} -->

- **Nested resources:** [Pattern]
  <!-- Example: /users/{userId}/tasks, /orders/{orderId}/items -->

**HTTP Methods:**

| Method | Purpose | Example |
|--------|---------|---------|
| GET | [Usage] | [Example endpoint] |
| POST | [Usage] | [Example endpoint] |
| PUT | [Usage] | [Example endpoint] |
| PATCH | [Usage] | [Example endpoint] |
| DELETE | [Usage] | [Example endpoint] |

<!--
Example:
| Method | Purpose | Example |
|--------|---------|---------|
| GET | Retrieve resource(s) | GET /users, GET /users/123 |
| POST | Create new resource | POST /users |
| PUT | Replace entire resource | PUT /users/123 |
| PATCH | Update partial resource | PATCH /users/123 |
| DELETE | Delete resource | DELETE /users/123 |
-->

**URL Structure Rules:**
- [Rule 1 - e.g., "Use lowercase letters"]
- [Rule 2 - e.g., "Use hyphens for multi-word resources (/user-profiles)"]
- [Rule 3 - e.g., "Avoid deep nesting (max 2-3 levels)"]
- [Rule 4 - e.g., "Use query parameters for filtering, sorting, pagination"]

### GraphQL Conventions (if applicable)

**Schema Organization:** [How schema is structured]

<!-- Examples: Single schema file, Modular schemas, Code-first vs Schema-first -->

**Naming Conventions:**
- **Queries:** [Pattern - e.g., "Nouns: user, users, task"]
- **Mutations:** [Pattern - e.g., "Verbs: createUser, updateTask, deleteOrder"]
- **Types:** [Pattern - e.g., "PascalCase: User, Task, Order"]

**Query Depth:** [Maximum nesting allowed]

<!-- Example: "Limit to 3-4 levels deep to prevent performance issues" -->

## Request/Response Formats

### Request Format

**Content Type:** [Standard content type]

<!-- Examples: application/json, application/xml, multipart/form-data for uploads -->

**Request Body Structure:**

```json
{
  // [Example request structure]
}
```

<!--
Example:
```json
{
  "data": {
    "field1": "value1",
    "field2": "value2"
  },
  "metadata": {
    "requestId": "uuid",
    "timestamp": "ISO 8601"
  }
}
```
-->

**Required Headers:**
- [Header 1 - e.g., "Authorization: Bearer {token}"]
- [Header 2 - e.g., "Content-Type: application/json"]
- [Header 3 - e.g., "X-Request-ID: {uuid}"]

### Response Format

**Success Response Structure:**

```json
{
  // [Example success response structure]
}
```

<!--
Example:
```json
{
  "success": true,
  "data": {
    "id": "123",
    "name": "John Doe",
    "email": "john@example.com"
  },
  "metadata": {
    "timestamp": "2024-01-15T10:30:00Z",
    "requestId": "uuid"
  }
}
```
-->

**Error Response Structure:**

```json
{
  // [Example error response structure]
}
```

<!--
Example:
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "User-friendly error message",
    "details": [
      {
        "field": "email",
        "message": "Email is required"
      }
    ]
  },
  "metadata": {
    "timestamp": "2024-01-15T10:30:00Z",
    "requestId": "uuid"
  }
}
```
-->

### Pagination

**Pagination Style:** [Method]

<!-- Examples: Offset-based, Cursor-based, Page-based -->

**Query Parameters:**
- [Parameter 1 - e.g., "page: Page number (default: 1)"]
- [Parameter 2 - e.g., "limit: Items per page (default: 20, max: 100)"]
- [Parameter 3 - e.g., "cursor: Next page cursor (for cursor-based pagination)"]

**Pagination Response:**

```json
{
  // [Example pagination metadata]
}
```

<!--
Example (offset-based):
```json
{
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "totalPages": 8,
    "hasNext": true,
    "hasPrevious": false
  }
}
```

Example (cursor-based):
```json
{
  "data": [...],
  "pagination": {
    "nextCursor": "encoded_cursor_string",
    "prevCursor": null,
    "hasMore": true
  }
}
```
-->

### Filtering & Sorting

**Filtering:**

[How to structure filter queries]

<!--
Examples:
- Query string: ?status=active&role=admin
- JSON in request body for complex filters
- GraphQL arguments: users(where: { isActive: true })
-->

**Sorting:**

[How to specify sort order]

<!--
Examples:
- Query string: ?sortBy=createdAt&order=desc
- Multiple fields: ?sort=lastName:asc,createdAt:desc
- GraphQL: users(orderBy: { createdAt: DESC })
-->

## HTTP Status Codes

### Standard Status Codes

**Success (2xx):**
- **200 OK:** [Usage - e.g., "Successful GET, PUT, PATCH requests"]
- **201 Created:** [Usage - e.g., "Successful POST request creating a resource"]
- **204 No Content:** [Usage - e.g., "Successful DELETE or update with no response body"]

**Client Errors (4xx):**
- **400 Bad Request:** [Usage - e.g., "Invalid request format or validation errors"]
- **401 Unauthorized:** [Usage - e.g., "Missing or invalid authentication"]
- **403 Forbidden:** [Usage - e.g., "Authenticated but lacks permission"]
- **404 Not Found:** [Usage - e.g., "Resource doesn't exist"]
- **409 Conflict:** [Usage - e.g., "Duplicate resource or conflicting state"]
- **422 Unprocessable Entity:** [Usage - e.g., "Validation errors on well-formed request"]
- **429 Too Many Requests:** [Usage - e.g., "Rate limit exceeded"]

**Server Errors (5xx):**
- **500 Internal Server Error:** [Usage - e.g., "Unexpected server error"]
- **503 Service Unavailable:** [Usage - e.g., "Server maintenance or overload"]

## Error Handling

### Error Response Format

**Error Structure:** [Consistent error format]

```json
{
  // [Error response example - see Response Format section above]
}
```

### Error Codes

**Application Error Codes:**

| Code | HTTP Status | Description | Example |
|------|-------------|-------------|---------|
| [CODE_1] | [Status] | [Description] | [When to use] |
| [CODE_2] | [Status] | [Description] | [When to use] |
| [CODE_3] | [Status] | [Description] | [When to use] |

<!--
Example:
| Code | HTTP Status | Description | Example |
|------|-------------|-------------|---------|
| VALIDATION_ERROR | 400 | Input validation failed | Missing required fields |
| UNAUTHORIZED | 401 | Invalid or missing token | Expired JWT |
| FORBIDDEN | 403 | Insufficient permissions | Non-admin accessing admin endpoint |
| NOT_FOUND | 404 | Resource not found | User ID doesn't exist |
| DUPLICATE_RESOURCE | 409 | Resource already exists | Email already registered |
| RATE_LIMIT_EXCEEDED | 429 | Too many requests | >100 requests per minute |
| INTERNAL_ERROR | 500 | Unexpected server error | Database connection failed |
-->

### Validation Errors

**Field-Level Errors:**

```json
{
  // [Example of field validation errors]
}
```

<!--
Example:
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Validation failed",
    "details": [
      {
        "field": "email",
        "message": "Email must be a valid email address",
        "code": "INVALID_FORMAT"
      },
      {
        "field": "password",
        "message": "Password must be at least 8 characters",
        "code": "TOO_SHORT"
      }
    ]
  }
}
```
-->

## Database Standards

### Naming Conventions

**Table Names:** [Convention]

<!-- Examples: plural_snake_case (users, order_items), PascalCase (Users, OrderItems) -->

**Column Names:** [Convention]

<!-- Examples: snake_case (first_name, created_at), camelCase (firstName, createdAt) -->

**Primary Keys:** [Convention]

<!-- Examples: id, {table_name}_id (user_id), uuid -->

**Foreign Keys:** [Convention]

<!-- Examples: {referenced_table}_id (user_id, order_id), {entity}Id (userId, orderId) -->

**Junction Tables:** [Convention]

<!-- Examples: user_roles, users_projects, user_project_assignments -->

### Column Types

**Common Field Standards:**

| Field Type | Database Type | Example |
|------------|---------------|---------|
| ID/Primary Key | [Type] | [Example] |
| Timestamp | [Type] | [Example] |
| Boolean | [Type] | [Example] |
| Money/Currency | [Type] | [Example] |
| Email | [Type] | [Example] |
| Enum/Status | [Type] | [Example] |

<!--
Example (PostgreSQL):
| Field Type | Database Type | Example |
|------------|---------------|---------|
| ID/Primary Key | UUID or SERIAL | id UUID PRIMARY KEY |
| Timestamp | TIMESTAMPTZ | created_at TIMESTAMPTZ NOT NULL |
| Boolean | BOOLEAN | is_active BOOLEAN DEFAULT true |
| Money/Currency | DECIMAL(10,2) | price DECIMAL(10,2) |
| Email | VARCHAR(255) | email VARCHAR(255) UNIQUE |
| Enum/Status | VARCHAR or ENUM | status VARCHAR(20) CHECK (status IN ('active', 'inactive')) |
-->

### Required Fields

**Standard Timestamp Fields:**
- [ ] [Field 1 - e.g., "created_at: When record was created"]
- [ ] [Field 2 - e.g., "updated_at: When record was last modified"]
- [ ] [Optional: deleted_at for soft deletes]

**Audit Fields (if applicable):**
- [ ] [Field 1 - e.g., "created_by: User ID who created record"]
- [ ] [Field 2 - e.g., "updated_by: User ID who last modified record"]

### Relationships

**One-to-Many:** [How to implement]

<!-- Example: "Foreign key in child table pointing to parent table's primary key" -->

**Many-to-Many:** [How to implement]

<!-- Example: "Junction table with foreign keys to both tables" -->

**Cascade Rules:** [Delete/update behavior]

<!-- Examples: "CASCADE on delete for dependent records", "SET NULL for optional relationships", "RESTRICT for critical relationships" -->

### Indexes

**When to Create Indexes:**
- [Criterion 1 - e.g., "Foreign keys"]
- [Criterion 2 - e.g., "Columns used in WHERE clauses frequently"]
- [Criterion 3 - e.g., "Columns used for sorting/ordering"]
- [Criterion 4 - e.g., "Unique constraints"]

**Index Naming:** [Convention]

<!-- Examples: idx_{table}_{column}, {table}_{column}_idx -->

### Migrations

**Migration Tool:** [Tool used]

<!-- Examples: Prisma Migrate, TypeORM migrations, Alembic, Flyway, Liquibase -->

**Migration Naming:** [Convention]

<!-- Examples: timestamp_description.sql, YYYYMMDDHHMMSS_create_users_table.ts -->

**Migration Rules:**
- [Rule 1 - e.g., "Never modify committed migrations"]
- [Rule 2 - e.g., "Include both up and down migrations"]
- [Rule 3 - e.g., "Test migrations on development/staging first"]
- [Rule 4 - e.g., "Keep migrations small and focused"]

## Data Validation

### Input Validation

**Validation Approach:** [Strategy]

<!-- Examples: Schema validation library (Zod, Joi, Yup), Framework validators, Manual validation -->

**What to Validate:**
- [ ] [Item 1 - e.g., "Required fields are present"]
- [ ] [Item 2 - e.g., "Data types are correct"]
- [ ] [Item 3 - e.g., "Values are within allowed ranges"]
- [ ] [Item 4 - e.g., "Format matches expected pattern (email, phone, etc.)"]
- [ ] [Item 5 - e.g., "Foreign keys reference existing records"]

### Validation Rules

**Common Validations:**

| Field Type | Validation Rules | Example |
|------------|------------------|---------|
| Email | [Rules] | [Example] |
| Password | [Rules] | [Example] |
| Phone | [Rules] | [Example] |
| URL | [Rules] | [Example] |
| Date | [Rules] | [Example] |

<!--
Example:
| Field Type | Validation Rules | Example |
|------------|------------------|---------|
| Email | Valid format, max 255 chars, unique | email: z.string().email().max(255) |
| Password | Min 8 chars, at least 1 uppercase, 1 number | password: z.string().min(8).regex(/[A-Z]/).regex(/[0-9]/) |
| Phone | Valid format for region | phone: z.string().regex(/^\+?[1-9]\d{1,14}$/) |
| URL | Valid HTTP/HTTPS URL | url: z.string().url() |
| Date | ISO 8601 format, not in past | date: z.string().datetime().refine(d => new Date(d) > new Date()) |
-->

## Authentication & Authorization

### Authentication

**Authentication Method:** [Method]

<!-- Examples: JWT tokens, Session-based, OAuth 2.0, API keys -->

**Token Format (if applicable):**

```
[Example token structure]
```

<!--
Example (JWT):
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```
-->

**Token Expiration:** [Duration]

<!-- Examples: "15 minutes for access token, 7 days for refresh token" -->

**Refresh Token Strategy:** [How tokens are refreshed]

<!-- Examples: "Use refresh tokens to get new access tokens", "Sliding expiration", "Absolute expiration" -->

### Authorization

**Authorization Model:** [Model]

<!-- Examples: RBAC (Role-Based Access Control), ABAC (Attribute-Based), ACL (Access Control List) -->

**Permission Levels:**

| Role | Permissions | Description |
|------|-------------|-------------|
| [Role 1] | [Permissions] | [Description] |
| [Role 2] | [Permissions] | [Description] |

<!--
Example:
| Role | Permissions | Description |
|------|-------------|-------------|
| Admin | Full access | Can manage all resources and users |
| Editor | Create, edit, delete own content | Can manage own resources |
| Viewer | Read-only | Can view resources but not modify |
-->

**Endpoint Protection:** [How to protect endpoints]

<!-- Examples: "Middleware checking JWT", "Decorator @RequireAuth()", "Route guards" -->

## API Documentation

### Documentation Tool

**Tool Used:** [Documentation tool]

<!-- Examples: Swagger/OpenAPI, Postman, GraphQL Playground, Stoplight, Redoc -->

**Documentation Location:** [Where docs are hosted/generated]

<!-- Examples: /api/docs, Separate docs site, Auto-generated from code comments -->

### Required Documentation

**For Each Endpoint:**
- [ ] Description of what it does
- [ ] Authentication requirements
- [ ] Request parameters/body schema
- [ ] Response schema with examples
- [ ] Possible error responses
- [ ] Rate limiting information (if applicable)

### API Versioning

**Breaking Changes:** [How to handle]

<!-- Examples: "Create new version (v2)", "Deprecate old version with 6-month notice", "Maintain both versions" -->

**Deprecation Policy:** [Policy]

<!-- Examples: "Announce 3 months in advance", "Add Deprecation header", "Provide migration guide" -->

## Performance & Rate Limiting

### Rate Limiting

**Rate Limits:** [Limits per endpoint/user]

<!-- Examples: "100 requests per minute per user", "1000 requests per hour per IP" -->

**Rate Limit Headers:**

```
[Example headers returned]
```

<!--
Example:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1640000000
```
-->

**Rate Limit Exceeded Response:**

```json
{
  // [Example 429 response]
}
```

### Caching

**Caching Strategy:** [Approach]

<!-- Examples: "Cache GET requests for 5 minutes", "ETags for conditional requests", "CDN caching for static data" -->

**Cache Headers:**

- [Header 1 - e.g., "Cache-Control: max-age=3600"]
- [Header 2 - e.g., "ETag: {hash}"]

## Security Standards

### Data Security

**Sensitive Data Handling:**
- [ ] [Rule 1 - e.g., "Never log passwords or tokens"]
- [ ] [Rule 2 - e.g., "Encrypt sensitive data at rest"]
- [ ] [Rule 3 - e.g., "Use HTTPS for all API communication"]
- [ ] [Rule 4 - e.g., "Hash passwords with bcrypt/argon2"]

### Input Sanitization

**Protection Against:**
- [ ] SQL Injection - [How - e.g., "Use parameterized queries"]
- [ ] XSS - [How - e.g., "Sanitize HTML input, escape output"]
- [ ] CSRF - [How - e.g., "CSRF tokens for state-changing operations"]
- [ ] [Other vulnerabilities]

### CORS

**CORS Policy:** [Configuration]

<!-- Examples: "Allow only production domain", "Allow localhost for development", "Specific allowed origins list" -->

**Allowed Methods:** [HTTP methods]

<!-- Example: GET, POST, PUT, PATCH, DELETE -->

**Allowed Headers:** [Headers]

<!-- Example: Content-Type, Authorization, X-Request-ID -->

## API Testing Standards

### Test Coverage

**Required Tests:**
- [ ] [Test type 1 - e.g., "All endpoints have integration tests"]
- [ ] [Test type 2 - e.g., "Validation errors are tested"]
- [ ] [Test type 3 - e.g., "Authentication/authorization is tested"]
- [ ] [Test type 4 - e.g., "Edge cases and error conditions"]

### Test Data

**Test Data Strategy:** [Approach]

<!-- Examples: "Seed database with fixtures", "Factory functions", "In-memory database for tests" -->

**Cleanup:** [How to clean up after tests]

<!-- Examples: "Rollback transactions", "Clear database between tests", "Use separate test database" -->

## Revision History

| Date | Author | Changes |
|------|--------|---------|
| [Date] | [Name] | Initial API & data standards definition |
| [Date] | [Name] | [Description of changes] |
