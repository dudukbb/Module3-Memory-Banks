# Coding Standards

<!-- This document defines the coding standards for [Project Name]. Use this as a reference when writing code and as context for AI coding tools to ensure consistent code style and patterns across the project. -->

## Overview

**Project Name:** [Project Name]  
**Primary Language(s):** [Language(s)]  
**Last Updated:** [Date]

## Language-Specific Conventions

### Code Formatting

**Indentation:** [Type and size]

<!-- Examples: 2 spaces, 4 spaces, tabs -->

**Line Length:** [Maximum characters per line]

<!-- Examples: 80, 100, 120 characters -->

**Semicolons:** [Required or optional]

<!-- Examples: "Always required", "Never use (rely on ASI)", "Language-dependent" -->

**Quotes:** [Single or double quotes]

<!-- Examples: "Single quotes for strings", "Double quotes preferred", "Template literals for interpolation" -->

**Trailing Commas:** [When to use]

<!-- Examples: "Always in multi-line arrays/objects", "Never", "ES5 style" -->

**Formatter Tool:** [Automated formatting]

<!-- Examples: Prettier, Black, gofmt, rustfmt, ESLint --fix -->

**Formatter Config:** [Where configuration lives]

<!-- Examples: .prettierrc, .editorconfig, pyproject.toml -->

### Naming Conventions

#### Variables

**Style:** [Naming style]

<!-- Examples: camelCase, snake_case, PascalCase -->

**Rules:**
- [Rule 1 - e.g., "Use descriptive names, avoid single letters except for iterators"]
- [Rule 2 - e.g., "Boolean variables should start with is/has/can"]
- [Rule 3 - e.g., "Avoid abbreviations unless widely known"]

<!--
Examples:
✅ Good: `isUserAuthenticated`, `hasPermission`, `canEditPost`
❌ Bad: `flag`, `x`, `usrAuth`
-->

#### Functions/Methods

**Style:** [Naming style]

<!-- Examples: camelCase, snake_case, PascalCase (for constructors) -->

**Rules:**
- [Rule 1 - e.g., "Use verbs for actions: get, set, create, update, delete"]
- [Rule 2 - e.g., "Be specific about what the function does"]
- [Rule 3 - e.g., "Keep function names concise but descriptive"]

<!--
Examples:
✅ Good: `getUserById`, `calculateTotal`, `validateEmail`
❌ Bad: `process`, `doStuff`, `handle`
-->

#### Classes/Types

**Style:** [Naming style]

<!-- Examples: PascalCase, UpperCamelCase -->

**Rules:**
- [Rule 1 - e.g., "Use nouns for class names"]
- [Rule 2 - e.g., "Interfaces should describe what they represent"]
- [Rule 3 - e.g., "Avoid generic names like Manager, Helper, Utility"]

<!--
Examples:
✅ Good: `UserRepository`, `PaymentService`, `OrderValidator`
❌ Bad: `DataManager`, `Helper`, `Utils`
-->

#### Constants

**Style:** [Naming style]

<!-- Examples: SCREAMING_SNAKE_CASE, camelCase with const, PascalCase -->

**Rules:**
- [Rule 1 - e.g., "Use all caps for primitive constants"]
- [Rule 2 - e.g., "Group related constants in objects/enums"]

<!--
Examples:
✅ Good: `MAX_RETRY_COUNT`, `API_BASE_URL`, `HttpStatus.OK`
❌ Bad: `maxRetryCount` (if truly constant), `url`
-->

#### Files and Folders

**File Names:** [Naming convention]

<!-- Examples: kebab-case.ts, PascalCase.tsx, snake_case.py -->

**Folder Names:** [Naming convention]

<!-- Examples: kebab-case, camelCase, lowercase -->

**Index Files:** [When and how to use]

<!-- Examples: "Use index.ts to export public API", "Avoid barrel files", "One export per index" -->

## File Organization

### File Structure

**Where to place different types of files:**

**Components:** [Location]

<!-- Examples: src/components/, app/components/, lib/ui/ -->

**Pages/Routes:** [Location]

<!-- Examples: src/pages/, app/routes/, views/ -->

**Business Logic:** [Location]

<!-- Examples: src/services/, lib/business/, domain/ -->

**Data Access:** [Location]

<!-- Examples: src/repositories/, lib/data/, models/ -->

**Utilities:** [Location]

<!-- Examples: src/utils/, lib/helpers/, shared/utils/ -->

**Types/Interfaces:** [Location]

<!-- Examples: src/types/, @types/, alongside usage, shared/types/ -->

**Tests:** [Location]

<!-- Examples: __tests__/, *.test.ts alongside source, tests/ separate -->

**Configuration:** [Location]

<!-- Examples: config/, root level, src/config/ -->

### File Size Guidelines

**Maximum File Size:** [Guideline]

<!-- Examples: "< 300 lines", "< 500 lines", "Split when exceeding 400 lines" -->

**When to Split Files:**
- [Criterion 1 - e.g., "Multiple unrelated functions/classes"]
- [Criterion 2 - e.g., "File becomes difficult to navigate"]
- [Criterion 3 - e.g., "Single Responsibility Principle violated"]

## Code Patterns

### Error Handling

**Primary Approach:** [Error handling strategy]

<!-- Examples: Try-catch blocks, Error return values, Result types, Exceptions -->

**Error Types:**

```[language]
[Example of custom error class or error handling pattern]
```

<!--
Example (TypeScript):
```typescript
class ValidationError extends Error {
  constructor(message: string, public field: string) {
    super(message);
    this.name = 'ValidationError';
  }
}
```
-->

**Error Handling Rules:**
- [Rule 1 - e.g., "Always catch and handle errors, never silently fail"]
- [Rule 2 - e.g., "Log errors with context (user ID, timestamp, stack trace)"]
- [Rule 3 - e.g., "Return user-friendly error messages, log technical details"]
- [Rule 4 - e.g., "Use custom error classes for different error types"]

### Logging

**Logging Library:** [Tool/library]

<!-- Examples: Winston, Pino, console.log, logging module, log4j -->

**Log Levels:** [When to use each level]

- **ERROR:** [Usage - e.g., "Unexpected errors, exceptions, failures"]
- **WARN:** [Usage - e.g., "Deprecated features, unusual conditions"]
- **INFO:** [Usage - e.g., "Important business events, service start/stop"]
- **DEBUG:** [Usage - e.g., "Detailed debugging information, variable values"]

**What to Log:**
- [ ] [Item 1 - e.g., "User authentication attempts"]
- [ ] [Item 2 - e.g., "API request/response (excluding sensitive data)"]
- [ ] [Item 3 - e.g., "Database queries in development"]
- [ ] [Item 4 - e.g., "Error stack traces"]

**What NOT to Log:**
- [ ] Passwords or API keys
- [ ] Personally identifiable information (PII)
- [ ] Credit card numbers
- [ ] [Other sensitive data]

### Validation

**Input Validation Approach:** [Strategy]

<!-- Examples: Schema validation (Zod, Joi), Manual checks, Framework validators -->

**Where to Validate:**
- [Location 1 - e.g., "At API entry points (controllers/routes)"]
- [Location 2 - e.g., "Before database operations"]
- [Location 3 - e.g., "On user input (client-side)"]

**Validation Rules:**
- [Rule 1 - e.g., "Validate all user inputs"]
- [Rule 2 - e.g., "Return specific validation errors with field names"]
- [Rule 3 - e.g., "Use schema validators for complex objects"]

### Async/Concurrency Patterns

**Async Pattern:** [Preferred approach]

<!-- Examples: async/await, Promises, Callbacks, Coroutines, Futures -->

**Rules:**
- [Rule 1 - e.g., "Always use async/await, avoid .then() chains"]
- [Rule 2 - e.g., "Handle Promise rejections with try-catch"]
- [Rule 3 - e.g., "Use Promise.all() for parallel operations"]
- [Rule 4 - e.g., "Avoid blocking operations in async functions"]

### Null/Undefined Handling

**Null Safety Approach:** [Strategy]

<!-- Examples: Strict null checks, Optional types, Null object pattern, Option/Maybe types -->

**Rules:**
- [Rule 1 - e.g., "Use optional chaining (?.) for nested properties"]
- [Rule 2 - e.g., "Prefer null over undefined for intentional absence"]
- [Rule 3 - e.g., "Use nullish coalescing (??) for default values"]
- [Rule 4 - e.g., "Check for null/undefined before using values"]

### Code Reusability

**DRY Principle:** [How to avoid repetition]

<!-- Examples: "Extract common logic into functions", "Use composition over inheritance", "Create utility functions" -->

**When to Abstract:**
- [Criterion 1 - e.g., "Code is duplicated 3+ times"]
- [Criterion 2 - e.g., "Logic is complex and reusable"]
- [Criterion 3 - e.g., "Abstraction improves readability"]

**When NOT to Abstract:**
- [Criterion 1 - e.g., "Code is similar but serves different purposes"]
- [Criterion 2 - e.g., "Abstraction adds unnecessary complexity"]
- [Criterion 3 - e.g., "Only used once or twice"]

## Documentation Requirements

### Code Comments

**When to Comment:**
- [Scenario 1 - e.g., "Complex algorithms or business logic"]
- [Scenario 2 - e.g., "Non-obvious workarounds or hacks"]
- [Scenario 3 - e.g., "Public APIs and library functions"]
- [Scenario 4 - e.g., "Regular expressions or complex data transformations"]

**When NOT to Comment:**
- [Scenario 1 - e.g., "Self-explanatory code"]
- [Scenario 2 - e.g., "Restating what the code does"]
- [Scenario 3 - e.g., "Outdated or incorrect information"]

**Comment Style:**

```[language]
// [Example of preferred comment style]
```

<!--
Example (TypeScript):
```typescript
/**
 * Calculates the total price including tax and discounts.
 * 
 * @param basePrice - The original price before tax/discounts
 * @param taxRate - Tax rate as a decimal (e.g., 0.1 for 10%)
 * @param discountCode - Optional discount code to apply
 * @returns The final price after tax and discounts
 */
function calculateFinalPrice(basePrice: number, taxRate: number, discountCode?: string): number {
  // Implementation...
}
```
-->

### Function/Method Documentation

**Documentation Format:** [Standard]

<!-- Examples: JSDoc, Docstrings (Google/NumPy style), JavaDoc, XML comments -->

**Required for:**
- [ ] [Item 1 - e.g., "All public functions/methods"]
- [ ] [Item 2 - e.g., "Complex internal functions"]
- [ ] [Item 3 - e.g., "API endpoints"]

**Must Include:**
- [ ] Description of what the function does
- [ ] Parameters and their types
- [ ] Return value and type
- [ ] Exceptions/errors that may be thrown
- [ ] [Optional: Examples of usage]

### README and Documentation

**Required Documentation:**
- [ ] README.md with project overview, setup instructions, usage
- [ ] CONTRIBUTING.md with development guidelines
- [ ] [Other required docs - e.g., API.md, ARCHITECTURE.md]

## Anti-Patterns to Avoid

### Code Smells

**Avoid:**
- [ ] [Anti-pattern 1 - e.g., "God objects (classes that do too much)"]
- [ ] [Anti-pattern 2 - e.g., "Magic numbers (use named constants)"]
- [ ] [Anti-pattern 3 - e.g., "Deeply nested conditionals (use early returns)"]
- [ ] [Anti-pattern 4 - e.g., "Commented-out code (delete it, use version control)"]
- [ ] [Anti-pattern 5 - e.g., "Excessive function parameters (use objects/config)"]

<!--
Examples:
❌ Bad:
```typescript
if (user) {
  if (user.isActive) {
    if (user.hasPermission('edit')) {
      // ... deeply nested logic
    }
  }
}
```

✅ Good:
```typescript
if (!user) return;
if (!user.isActive) return;
if (!user.hasPermission('edit')) return;
// ... flat logic
```
-->

### Common Mistakes

**Don't:**
- [ ] [Mistake 1 - e.g., "Mutate function parameters"]
- [ ] [Mistake 2 - e.g., "Use var in JavaScript (use const/let)"]
- [ ] [Mistake 3 - e.g., "Ignore TypeScript errors with @ts-ignore"]
- [ ] [Mistake 4 - e.g., "Use any type extensively in TypeScript"]
- [ ] [Mistake 5 - e.g., "Mix synchronous and asynchronous patterns"]

## Language-Specific Idioms

### [Language Name] Best Practices

**Preferred Patterns:**

```[language]
[Example of idiomatic code in your language]
```

<!--
Example (JavaScript/TypeScript):
```typescript
// Destructuring for cleaner code
const { firstName, lastName } = user;

// Spread operator for immutability
const updatedUser = { ...user, isActive: true };

// Array methods over loops
const activeUsers = users.filter(u => u.isActive);
const userNames = users.map(u => u.name);

// Optional chaining for safe property access
const city = user?.address?.city;

// Template literals for string interpolation
const message = `Hello, ${user.name}!`;
```
-->

**Avoid:**

```[language]
[Example of what NOT to do]
```

<!--
Example (JavaScript/TypeScript):
```typescript
// ❌ Don't mutate arrays
users.push(newUser);

// ✅ Create new arrays
const updatedUsers = [...users, newUser];

// ❌ Don't use == (loose equality)
if (value == null)

// ✅ Use === (strict equality)
if (value === null)
```
-->

## Code Review Checklist

Use this checklist when reviewing code (AI or human):

### Functionality
- [ ] Code does what it's supposed to do
- [ ] Edge cases are handled
- [ ] Error handling is appropriate

### Code Quality
- [ ] Follows naming conventions
- [ ] No code duplication
- [ ] Functions are small and focused
- [ ] Code is readable and self-documenting

### Standards Compliance
- [ ] Matches our coding style
- [ ] Uses approved patterns
- [ ] Avoids known anti-patterns
- [ ] Follows file organization rules

### Testing
- [ ] New code has tests
- [ ] Tests are meaningful and cover important cases
- [ ] Existing tests still pass

### Documentation
- [ ] Complex logic is commented
- [ ] Public APIs are documented
- [ ] README updated if needed

### Security
- [ ] No sensitive data exposed
- [ ] Input validation present
- [ ] No SQL injection or XSS vulnerabilities

### Performance
- [ ] No obvious performance issues
- [ ] Database queries are optimized
- [ ] Appropriate data structures used

## Revision History

| Date | Author | Changes |
|------|--------|---------|
| [Date] | [Name] | Initial coding standards definition |
| [Date] | [Name] | [Description of changes] |
