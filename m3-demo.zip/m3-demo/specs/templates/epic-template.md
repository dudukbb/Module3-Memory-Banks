# Epic: [Epic Title]

<!-- Replace [Epic Title] with a concise, action-oriented name (e.g., "User Authentication System", "Real-time Notifications") -->

## Description

[Provide a clear 2-3 sentence description of what this epic delivers and why it matters. Focus on the business value and user impact rather than technical implementation.]

<!-- Example: This epic introduces a comprehensive authentication system that allows users to securely create accounts, log in, and manage their profiles. It establishes the foundation for personalized user experiences and enables feature access control across the platform. -->

## Primary Persona

**Target User:** [Persona Name]

<!-- Identify who benefits most from this epic. Examples: "End User", "Admin", "Content Creator", "Developer", "Power User" -->

**Key Needs:**
- [What pain point does this solve?]
- [What goal does this help achieve?]

## Success Criteria

<!-- Define measurable outcomes that indicate this epic is complete and successful -->

- [ ] [Quantifiable metric or outcome - e.g., "95% of users can complete signup in under 2 minutes"]
- [ ] [Functional requirement - e.g., "All user roles can authenticate via OAuth and email/password"]
- [ ] [Business metric - e.g., "Reduces support tickets related to account access by 60%"]
- [ ] [Technical requirement - e.g., "System handles 1000 concurrent authentication requests"]

## Scope/Complexity

**Estimate:** [S / M / L]

<!-- 
- S (Small): 1-2 weeks, single team, minimal dependencies
- M (Medium): 2-6 weeks, may involve multiple teams, moderate complexity
- L (Large): 6+ weeks, cross-team effort, significant architectural changes
-->

**Rationale:** [Brief explanation of the complexity estimate]

## Dependencies

### Required (Must exist before work begins)
- [ ] [Dependency 1 - e.g., "Database infrastructure provisioned"]
- [ ] [Dependency 2 - e.g., "API gateway configured"]

### Related (May impact or be impacted by this work)
- [Related Epic/Feature 1]
- [Related Epic/Feature 2]

### Assumptions
- [Key assumption 1]
- [Key assumption 2]

## User Stories

<!-- User stories will be created and linked here as this epic is broken down into implementable units -->

### In Progress
- [ ] [Story ID/Link] - [Brief description]

### Planned
- [ ] [Story ID/Link] - [Brief description]

### Completed
- [x] [Story ID/Link] - [Brief description]

---

## Additional Notes

<!-- Optional section for:
- Technical considerations
- Design mockup links
- Research findings
- Open questions
- Out of scope items
-->

**Out of Scope:**
- [Item explicitly not included in this epic]

**Open Questions:**
- [ ] [Question 1]
- [ ] [Question 2]
