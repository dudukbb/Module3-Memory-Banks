# Story ID: [US-XXX] - [Short Title]

<!-- Replace with unique identifier (e.g., US-001, US-042) and a brief, descriptive title -->

## User Story

**As a** [persona/user role]  
**I want** [action/capability]  
**So that** [benefit/value/outcome]

<!-- 
Example:
As a project manager
I want to filter tasks by assignee and status
So that I can quickly identify bottlenecks and reassign work
-->

## Acceptance Criteria

<!-- Define 3-5 specific, testable conditions that must be met for this story to be considered complete -->

- [ ] **Given** [context/precondition], **When** [action/event], **Then** [expected outcome]
- [ ] **Given** [context/precondition], **When** [action/event], **Then** [expected outcome]
- [ ] **Given** [context/precondition], **When** [action/event], **Then** [expected outcome]

<!-- 
Alternative format (simple checklist):
- [ ] [Specific, testable condition 1]
- [ ] [Specific, testable condition 2]
- [ ] [Specific, testable condition 3]

Example:
- [ ] Given I am on the task board, When I click the filter dropdown, Then I see options for "All", "Active", "Completed", "Blocked"
- [ ] Given I select a filter, When the page refreshes, Then only tasks matching that status are displayed
- [ ] Given filters are applied, When I clear all filters, Then all tasks are visible again
-->

## Technical Notes

<!-- Optional section for implementation hints, architectural considerations, or technical constraints -->

**Implementation Hints:**
- [Suggested approach, library, or pattern]
- [API endpoints or data models involved]
- [Performance or security considerations]

**Affected Components:**
- [Component/module 1]
- [Component/module 2]

**Technical Dependencies:**
- [Required library, service, or infrastructure]

<!-- Example:
Implementation Hints:
- Use the existing FilterService for status filtering
- Add new query parameter "assignee" to /api/tasks endpoint
- Consider caching filter results for improved performance

Affected Components:
- TaskBoard component (frontend)
- TaskController (backend API)
- TaskRepository (data layer)
-->

## Estimation

**Story Points:** [1, 2, 3, 5, 8, 13, 21] or **Days:** [0.5, 1, 2, 3, 5]

<!-- 
Story Points (Fibonacci sequence):
- 1-2: Simple, well-understood work
- 3-5: Moderate complexity, some unknowns
- 8+: Complex, should consider breaking down further

Days are an alternative if your team prefers time-based estimates
-->

**Rationale:** [Brief explanation of the estimate]

## Related Links

- **Epic:** [Link to parent epic]
- **Design:** [Link to mockups/wireframes]
- **Discussion:** [Link to related tickets or conversations]

---

<!--
INVEST VALIDATION CHECKLIST
Use this checklist to validate your user story follows INVEST principles:

[ ] Independent - Can this story be developed and delivered independently of other stories?
    • Minimal dependencies on other incomplete work
    • Can be prioritized and scheduled flexibly
    
[ ] Negotiable - Is the story flexible enough to allow discussion about implementation?
    • Describes the "what" and "why", not the "how"
    • Leaves room for team input on technical approach
    • Acceptance criteria focus on outcomes, not specific solutions
    
[ ] Valuable - Does this story deliver clear value to the user or business?
    • Provides tangible benefit to the persona
    • Can articulate the value in the "so that" clause
    • Stakeholders would notice if this wasn't delivered
    
[ ] Estimable - Can the team reasonably estimate the effort required?
    • Requirements are clear enough to size
    • Team has sufficient knowledge/context
    • Any unknowns are identified in technical notes
    
[ ] Small - Is the story small enough to complete in one sprint/iteration?
    • Can be completed in 1-5 days (or 1-8 story points)
    • If larger, consider breaking into smaller stories
    • Single story shouldn't span multiple team members for weeks
    
[ ] Testable - Can we verify this story is complete through testing?
    • Acceptance criteria are specific and measurable
    • Clear pass/fail conditions exist
    • Can write test cases directly from acceptance criteria

If any INVEST principle is violated, revise the story before starting work.
-->
