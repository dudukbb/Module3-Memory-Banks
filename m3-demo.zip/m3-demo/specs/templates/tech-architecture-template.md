# Technical Architecture Standards

<!-- This document defines the technical architecture standards for [Project Name]. Use this as a reference when making architectural decisions and as context for AI coding tools to ensure consistent implementation. -->

## Project Overview

**Project Name:** [Project Name]  
**Project Type:** [Web Application / Mobile App / API Service / Desktop Application / etc.]  
**Last Updated:** [Date]

## Technology Stack

### Core Technologies

**Programming Language(s):** [Primary Language]

<!-- Examples: JavaScript/TypeScript, Python, Java, C#, Go, Rust -->

**Runtime/Platform:** [Runtime Environment]

<!-- Examples: Node.js 20.x, Python 3.12, .NET 8, JVM 17 -->

### Frontend (if applicable)

**Framework:** [Frontend Framework]

<!-- Examples: React 18, Vue 3, Angular 17, Svelte, Next.js, Nuxt -->

**UI Library/Components:** [Component Library]

<!-- Examples: Material-UI, Ant Design, Tailwind CSS, Bootstrap, Custom -->

**State Management:** [State Management Solution]

<!-- Examples: Redux, Zustand, Pinia, NgRx, Context API, Signals -->

**Build Tools:** [Build Tooling]

<!-- Examples: Vite, Webpack, esbuild, Turbopack -->

### Backend (if applicable)

**Framework:** [Backend Framework]

<!-- Examples: Express, Fastify, NestJS, Django, FastAPI, Spring Boot, ASP.NET Core -->

**API Style:** [API Architecture]

<!-- Examples: REST, GraphQL, gRPC, tRPC, WebSocket -->

**Authentication:** [Auth Mechanism]

<!-- Examples: JWT, OAuth 2.0, Session-based, Passport.js, Auth0, Supabase Auth -->

### Database

**Primary Database:** [Database Type and Version]

<!-- Examples: PostgreSQL 16, MySQL 8, MongoDB 7, SQLite, Supabase, Firebase -->

**ORM/Query Builder:** [Data Access Layer]

<!-- Examples: Prisma, TypeORM, Sequelize, SQLAlchemy, Entity Framework, Drizzle -->

**Caching (if applicable):** [Caching Solution]

<!-- Examples: Redis, Memcached, In-memory caching, CDN caching -->

### Infrastructure & DevOps

**Hosting/Cloud Provider:** [Infrastructure]

<!-- Examples: Vercel, AWS, Google Cloud, Azure, Railway, Fly.io, Self-hosted -->

**CI/CD:** [Continuous Integration/Deployment]

<!-- Examples: GitHub Actions, GitLab CI, CircleCI, Jenkins -->

**Monitoring & Logging:** [Observability Tools]

<!-- Examples: Sentry, LogRocket, DataDog, New Relic, CloudWatch, Simple logging -->

**Package Manager:** [Dependency Management]

<!-- Examples: npm, pnpm, yarn, pip, poetry, maven, gradle, nuget -->

## Architecture Patterns

### Overall Architecture Style

**Pattern:** [Architectural Pattern]

<!-- 
Examples:
- Monolithic (single deployable unit)
- Layered/N-tier (presentation, business, data layers)
- Microservices (distributed services)
- Serverless (function-as-a-service)
- Modular Monolith (logical modules, single deployment)
- Jamstack (JavaScript, APIs, Markup)
-->

**Rationale:** [Why this pattern was chosen]

### Frontend Architecture (if applicable)

**Component Structure:** [Component Organization Pattern]

<!-- Examples: Atomic Design, Feature-based, Smart/Dumb components, Container/Presentational -->

**Routing:** [Routing Approach]

<!-- Examples: Client-side routing, File-based routing, Server-side routing, Hybrid -->

**Data Fetching:** [Data Loading Pattern]

<!-- Examples: SWR, React Query, Server Components, Traditional REST calls, GraphQL client -->

### Backend Architecture (if applicable)

**Layer Organization:**

<!-- Define your application layers and their responsibilities -->

- **[Layer 1 Name]:** [Responsibility]
- **[Layer 2 Name]:** [Responsibility]
- **[Layer 3 Name]:** [Responsibility]

<!--
Example for a typical layered architecture:
- **Presentation Layer (Controllers/Routes):** Handle HTTP requests/responses, validation, routing
- **Business Logic Layer (Services):** Implement core business rules, orchestrate operations
- **Data Access Layer (Repositories):** Database operations, queries, data mapping
- **Domain Layer (Models/Entities):** Define data structures and business entities
-->

**Dependency Flow:** [How dependencies should flow between layers]

<!-- Examples: "Always depend inward (presentation → business → data)", "Use dependency injection", "Follow clean architecture principles" -->

## Project Structure

### Folder Organization

```
[root-folder]/
├── [folder-1]/          # [Description]
├── [folder-2]/          # [Description]
├── [folder-3]/          # [Description]
└── [config-files]       # [Description]
```

<!--
Example for a React/Node.js project:
```
my-app/
├── src/
│   ├── components/      # Reusable UI components
│   ├── pages/           # Page-level components (routes)
│   ├── services/        # API calls and external services
│   ├── hooks/           # Custom React hooks
│   ├── utils/           # Helper functions and utilities
│   ├── types/           # TypeScript type definitions
│   └── styles/          # Global styles and themes
├── public/              # Static assets
├── tests/               # Test files
└── docs/                # Documentation
```
-->

### File Naming Conventions

**Components/Classes:** [Naming Convention]

<!-- Examples: PascalCase (UserProfile.tsx), kebab-case (user-profile.tsx), camelCase (userProfile.tsx) -->

**Utilities/Helpers:** [Naming Convention]

<!-- Examples: camelCase (formatDate.ts), kebab-case (format-date.ts) -->

**Test Files:** [Naming Convention]

<!-- Examples: *.test.ts, *.spec.ts, __tests__/filename.ts -->

**Config Files:** [Naming Convention]

<!-- Examples: kebab-case (database-config.ts), camelCase (databaseConfig.ts) -->

## Integration Patterns

### API Communication

**Internal APIs:** [How services communicate]

<!-- Examples: RESTful JSON, GraphQL queries, gRPC, Direct function calls -->

**External APIs:** [How to integrate third-party services]

<!-- Examples: Adapter pattern, Service wrappers, Direct SDK usage -->

**Error Handling:** [How to handle API errors]

<!-- Examples: Try-catch with custom error classes, Error boundaries, Global error handlers -->

### State Management

**Global State:** [When and how to use global state]

<!-- Examples: Only for truly global data (auth, theme), Keep minimal, Use context sparingly -->

**Local State:** [When to use component-level state]

<!-- Examples: UI state, form state, temporary data -->

**Server State:** [How to manage data from APIs]

<!-- Examples: React Query for caching, SWR, Redux with RTK Query, Manual fetch + state -->

### Event Handling

**User Events:** [How to handle user interactions]

<!-- Examples: Event handlers in components, Command pattern, Event bus -->

**System Events:** [How to handle background/async events]

<!-- Examples: Event emitters, Message queues, Webhooks, Polling -->

## Infrastructure Standards

### Environment Configuration

**Environment Variables:** [How to manage configuration]

<!-- Examples: .env files, Environment-specific configs, Secret management service -->

**Required Environments:**
- [ ] Development
- [ ] Staging/QA
- [ ] Production

### Deployment Strategy

**Deployment Method:** [How code is deployed]

<!-- Examples: Git push to main → auto-deploy, Manual releases, Blue-green deployment -->

**Versioning:** [How to version releases]

<!-- Examples: Semantic versioning (semver), Date-based, Commit SHA -->

### Performance Standards

**Target Metrics:**
- **Page Load Time:** [Target - e.g., < 3 seconds]
- **API Response Time:** [Target - e.g., < 200ms for 95th percentile]
- **Bundle Size:** [Target - e.g., < 500KB initial JS]
- **Lighthouse Score:** [Target - e.g., > 90]

### Security Standards

**Authentication Requirements:**
- [ ] [Requirement 1 - e.g., "All API endpoints require authentication"]
- [ ] [Requirement 2 - e.g., "Passwords must be hashed with bcrypt"]

**Data Protection:**
- [ ] [Standard 1 - e.g., "Sensitive data encrypted at rest"]
- [ ] [Standard 2 - e.g., "HTTPS required for all communications"]

## Testing Standards

### Testing Strategy

**Unit Tests:** [Coverage and approach]

<!-- Examples: "Test all business logic functions", "Minimum 80% coverage", "Use Jest" -->

**Integration Tests:** [Coverage and approach]

<!-- Examples: "Test API endpoints", "Test database interactions", "Use Supertest" -->

**E2E Tests:** [Coverage and approach]

<!-- Examples: "Test critical user flows", "Use Playwright", "Run on staging only" -->

### Test Organization

**Test File Location:** [Where tests live]

<!-- Examples: "__tests__ folder", "Alongside source files (*.test.ts)", "Separate /tests directory" -->

**Test Naming:** [How to name tests]

<!-- Examples: "describe('ComponentName')", "it('should do something when condition')" -->

## Documentation Standards

### Code Documentation

**Required Documentation:**
- [ ] README.md with setup instructions
- [ ] API documentation (if backend)
- [ ] Component documentation (if frontend library)
- [ ] Architecture decision records (ADRs) for major decisions

**Inline Comments:** [When to use comments]

<!-- Examples: "Only for complex logic", "Explain why, not what", "Use JSDoc for public APIs" -->

## Third-Party Dependencies

### Dependency Guidelines

**Adding Dependencies:** [Process for adding new packages]

<!-- Examples: "Require team review", "Check bundle size impact", "Prefer well-maintained libraries" -->

**Allowed Licenses:** [Acceptable open-source licenses]

<!-- Examples: MIT, Apache 2.0, BSD, ISC (avoid GPL in commercial projects) -->

**Update Strategy:** [How to keep dependencies current]

<!-- Examples: "Monthly security updates", "Quarterly version updates", "Use Dependabot" -->

---

## Validation Checklist

Use this checklist when making architectural decisions:

- [ ] **Consistency:** Does this align with our existing technology stack?
- [ ] **Scalability:** Can this scale with our expected growth?
- [ ] **Maintainability:** Will the team be able to maintain this long-term?
- [ ] **Performance:** Does this meet our performance requirements?
- [ ] **Security:** Have security implications been considered?
- [ ] **Cost:** Is the cost (licensing, hosting, development time) acceptable?
- [ ] **Team Skills:** Does the team have expertise in this technology?
- [ ] **Community Support:** Is there good documentation and community support?
- [ ] **Testing:** Can this be easily tested?
- [ ] **Documentation:** Is this decision documented for future reference?

## Revision History

| Date | Author | Changes |
|------|--------|---------|
| [Date] | [Name] | Initial architecture definition |
| [Date] | [Name] | [Description of changes] |
